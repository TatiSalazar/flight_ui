import { Injectable } from '@angular/core';
import { Pasajero } from '../Modelo/Pasajero';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class ServiceService {

  constructor(private http:HttpClient) { }

  //pasajero: Pasajero;

  Url = 'http://localhost:8090/pasajeros/';
  
  // public getAllPasajerosById(id): Observable<any>{
  //   return this.httpClient.get(this.API_SERVER+id);
  // }

   getPasajeros(){
    return this.http.get<Pasajero[]>(this.Url);
  }
    createPasajero(pasajero:Pasajero){
      return this.http.post<Pasajero>(this.Url,pasajero);
    }
    getPasajeroId(id:number){
      return this.http.get<Pasajero>(this.Url+""+id);
    }
    updatePasajero(pasajero:Pasajero){
      return this.http.post<Pasajero>(this.Url+"/modificar/"+pasajero.id,pasajero);
    }
    deletePasajero(pasajero:Pasajero){
      return this.http.delete<Pasajero>(this.Url+"/delete/"+pasajero.id);
    }
  
  // public savePasajero(pasajero:any): Observable<any>{
  //   return this.httpClient.post(this.API_SERVER,pasajero);
  // }
  // public deletePasajero(id):Observable<any>{
  //   return this.httpClient.delete(this.API_SERVER + "delete/"+id);
  // }
  // public modifyPasajero(pasajero:any,id): Observable<any>{
  //   return this.httpClient.post(this.API_SERVER+"modificar/"+id,pasajero);
  // }
  // //vuelos
  // public getAllVuelos(): Observable<any>{
  //   return this.httpClient.get(this.API_SERVER);
  // }

  // public getAllVuelosByID(id): Observable<any>{
  //   return this.httpClient.get(this.API_SERVER+id);
  // }
}
