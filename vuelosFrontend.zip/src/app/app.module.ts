import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ListarComponent } from './Pasajero/listar/listar.component';
import { EditComponent } from './Pasajero/edit/edit.component';
import { AddComponent } from './Pasajero/add/add.component';
import { ListarVuelosComponent } from './Vuelos/listar-vuelos/listar-vuelos.component';
import { ListarVuelosPComponent } from './Vuelos/listar-vuelos-p/listar-vuelos-p.component';

import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import {FormsModule} from '@angular/forms';
import {ServiceService} from '../app/Service/service.service';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './Home/home/home.component';
//import { HttpClientModule, HttpClient } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ListarComponent,
    EditComponent,
    AddComponent,
    ListarVuelosComponent,
    ListarVuelosPComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,RouterModule,AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
