import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-vuelos-p',
  templateUrl: './listar-vuelos-p.component.html',
  styleUrls: ['./listar-vuelos-p.component.css']
})
export class ListarVuelosPComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
