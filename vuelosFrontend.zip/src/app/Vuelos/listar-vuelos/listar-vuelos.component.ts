import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-vuelos',
  templateUrl: './listar-vuelos.component.html',
  styleUrls: ['./listar-vuelos.component.css']
})
export class ListarVuelosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
