export class Pasajero {
    id: number;
    nombre: String;
    documento: String;
    email: String;
    telefono: String;
}